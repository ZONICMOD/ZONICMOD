// PUBG MOBILE (3.9.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Mon Jul  7 13:18:15 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function PixUIProfiler.PxProfilerMgr.SetPrintSizeChange
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bPrintSizeChange               (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UPxProfilerMgr::SetPrintSizeChange(bool bPrintSizeChange)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function PixUIProfiler.PxProfilerMgr.SetPrintSizeChange");

	UPxProfilerMgr_SetPrintSizeChange_Params params;
	params.bPrintSizeChange = bPrintSizeChange;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function PixUIProfiler.PxProfilerMgr.SetPrintCountChange
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           bPrintCountChange              (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UPxProfilerMgr::SetPrintCountChange(bool bPrintCountChange)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function PixUIProfiler.PxProfilerMgr.SetPrintCountChange");

	UPxProfilerMgr_SetPrintCountChange_Params params;
	params.bPrintCountChange = bPrintCountChange;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function PixUIProfiler.PxProfilerMgr.Print
// (Final, Native, Static, Public, BlueprintCallable)

void UPxProfilerMgr::Print()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function PixUIProfiler.PxProfilerMgr.Print");

	UPxProfilerMgr_Print_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function PixUIProfiler.PxProfilerMgr.Check
// (Final, Native, Static, Public, BlueprintCallable)

void UPxProfilerMgr::Check()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function PixUIProfiler.PxProfilerMgr.Check");

	UPxProfilerMgr_Check_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function PixUIProfiler.PxProfilerMgr.BePrintSizeChange
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UPxProfilerMgr::BePrintSizeChange()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function PixUIProfiler.PxProfilerMgr.BePrintSizeChange");

	UPxProfilerMgr_BePrintSizeChange_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function PixUIProfiler.PxProfilerMgr.BePrintCountChange
// (Final, Native, Static, Public, BlueprintCallable)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UPxProfilerMgr::BePrintCountChange()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function PixUIProfiler.PxProfilerMgr.BePrintCountChange");

	UPxProfilerMgr_BePrintCountChange_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


}

