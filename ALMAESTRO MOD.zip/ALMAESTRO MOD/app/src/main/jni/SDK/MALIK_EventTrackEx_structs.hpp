#pragma once

// PUBG MOBILE (3.9.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Mon Jul  7 13:18:14 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum EventTrackEx.EXTQTEOperationArea
enum class EXTQTEOperationArea : uint8_t
{
	EXTQTEOperationArea__Random    = 0,
	EXTQTEOperationArea__Left      = 1,
	EXTQTEOperationArea__Right     = 2,
	EXTQTEOperationArea__EXTQTEOperationArea_MAX = 3
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct EventTrackEx.XTEventPayload
// 0x0060
struct FXTEventPayload
{
	struct FName                                       EventName;                                                // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FString                                     MsgName;                                                  // 0x0008(0x000C) (Edit, ZeroConstructor)
	struct FString                                     Param1;                                                   // 0x0014(0x000C) (Edit, ZeroConstructor)
	struct FString                                     Param2;                                                   // 0x0020(0x000C) (Edit, ZeroConstructor)
	struct FString                                     param3;                                                   // 0x002C(0x000C) (Edit, ZeroConstructor)
	struct FString                                     Param4;                                                   // 0x0038(0x000C) (Edit, ZeroConstructor)
	struct FString                                     Param5;                                                   // 0x0044(0x000C) (Edit, ZeroConstructor)
	struct FString                                     Param6;                                                   // 0x0050(0x000C) (Edit, ZeroConstructor)
	unsigned char                                      UnknownData00[0x4];                                       // 0x005C(0x0004) MISSED OFFSET
};

// ScriptStruct EventTrackEx.MovieSceneXTEventSectionData
// 0x0018
struct FMovieSceneXTEventSectionData
{
	TArray<float>                                      KeyTimes;                                                 // 0x0000(0x000C) (ZeroConstructor)
	TArray<struct FXTEventPayload>                     KeyValues;                                                // 0x000C(0x000C) (ZeroConstructor)
};

// ScriptStruct EventTrackEx.MovieSceneXTEventSectionTemplate
// 0x0028 (0x0034 - 0x000C)
struct FMovieSceneXTEventSectionTemplate : public FMovieSceneEvalTemplate
{
	struct FMovieSceneXTEventSectionData               EventData;                                                // 0x000C(0x0018)
	TArray<struct FMovieSceneObjectBindingID>          EventReceivers;                                           // 0x0024(0x000C) (ZeroConstructor)
	unsigned char                                      bFireEventsWhenForwards : 1;                              // 0x0030(0x0001)
	unsigned char                                      bFireEventsWhenBackwards : 1;                             // 0x0030(0x0001)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0031(0x0003) MISSED OFFSET
};

// ScriptStruct EventTrackEx.MovieSceneXTQTETemplate
// 0x0004 (0x0010 - 0x000C)
struct FMovieSceneXTQTETemplate : public FMovieSceneEvalTemplate
{
	class UMovieSceneXTQTESection*                     Section;                                                  // 0x000C(0x0004) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

}

