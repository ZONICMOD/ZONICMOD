// PUBG MOBILE (3.9.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Mon Jul  7 13:18:14 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function MainCity.CarryBackMCAnimInstance.HandlePlayerPoseChange
// (Native, Public)
// Parameters:
// TEnumAsByte<ESTEPoseState>     LastPose                       (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<ESTEPoseState>     NewPose                        (Parm, ZeroConstructor, IsPlainOldData)

void UCarryBackMCAnimInstance::HandlePlayerPoseChange(TEnumAsByte<ESTEPoseState> LastPose, TEnumAsByte<ESTEPoseState> NewPose)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CarryBackMCAnimInstance.HandlePlayerPoseChange");

	UCarryBackMCAnimInstance_HandlePlayerPoseChange_Params params;
	params.LastPose = LastPose;
	params.NewPose = NewPose;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharLocomotionMCAnimInstance.SwitchingPoseFinishCallback
// (Final, Native, Public)

void UCharLocomotionMCAnimInstance::SwitchingPoseFinishCallback()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharLocomotionMCAnimInstance.SwitchingPoseFinishCallback");

	UCharLocomotionMCAnimInstance_SwitchingPoseFinishCallback_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharLocomotionMCAnimInstance.SetViewPointLimitByPoseStatus
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// ECharacterAnimBlendPoseType    InPoseType                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// bool                           bEnter                         (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UCharLocomotionMCAnimInstance::SetViewPointLimitByPoseStatus(ECharacterAnimBlendPoseType InPoseType, bool bEnter)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharLocomotionMCAnimInstance.SetViewPointLimitByPoseStatus");

	UCharLocomotionMCAnimInstance_SetViewPointLimitByPoseStatus_Params params;
	params.InPoseType = InPoseType;
	params.bEnter = bEnter;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharLocomotionMCAnimInstance.SetInterruptPose
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// bool                           bUseInterruptPose              (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<ECharacterPoseType> InterruptPose                  (Parm, ZeroConstructor, IsPlainOldData)

void UCharLocomotionMCAnimInstance::SetInterruptPose(bool bUseInterruptPose, TEnumAsByte<ECharacterPoseType> InterruptPose)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharLocomotionMCAnimInstance.SetInterruptPose");

	UCharLocomotionMCAnimInstance_SetInterruptPose_Params params;
	params.bUseInterruptPose = bUseInterruptPose;
	params.InterruptPose = InterruptPose;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharLocomotionMCAnimInstance.LeaveStateCallback
// (Final, Native, Public)

void UCharLocomotionMCAnimInstance::LeaveStateCallback()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharLocomotionMCAnimInstance.LeaveStateCallback");

	UCharLocomotionMCAnimInstance_LeaveStateCallback_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharLocomotionMCAnimInstance.HandleStateLeave
// (Final, Native, Public)
// Parameters:
// EPawnState                     LeaveState                     (Parm, ZeroConstructor, IsPlainOldData)

void UCharLocomotionMCAnimInstance::HandleStateLeave(EPawnState LeaveState)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharLocomotionMCAnimInstance.HandleStateLeave");

	UCharLocomotionMCAnimInstance_HandleStateLeave_Params params;
	params.LeaveState = LeaveState;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharLocomotionMCAnimInstance.HandlePlayerPoseChange
// (Native, Public)
// Parameters:
// TEnumAsByte<ESTEPoseState>     LastPose                       (Parm, ZeroConstructor, IsPlainOldData)
// TEnumAsByte<ESTEPoseState>     NewPose                        (Parm, ZeroConstructor, IsPlainOldData)

void UCharLocomotionMCAnimInstance::HandlePlayerPoseChange(TEnumAsByte<ESTEPoseState> LastPose, TEnumAsByte<ESTEPoseState> NewPose)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharLocomotionMCAnimInstance.HandlePlayerPoseChange");

	UCharLocomotionMCAnimInstance_HandlePlayerPoseChange_Params params;
	params.LastPose = LastPose;
	params.NewPose = NewPose;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharMainMCAnimInstance.SetClimbAnimation
// (Final, Native, Public)
// Parameters:
// class UAnimSequence*           AnimSequence                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bFlag                          (Parm, ZeroConstructor, IsPlainOldData)

void UCharMainMCAnimInstance::SetClimbAnimation(class UAnimSequence* AnimSequence, bool bFlag)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharMainMCAnimInstance.SetClimbAnimation");

	UCharMainMCAnimInstance_SetClimbAnimation_Params params;
	params.AnimSequence = AnimSequence;
	params.bFlag = bFlag;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharMainMCAnimInstance.HandlePlayerAnimMontagePlayExtraDelegate
// (Final, Native, Public)
// Parameters:
// class UAnimMontage*            MontageToPlay                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bWantsPlay                     (Parm, ZeroConstructor, IsPlainOldData)
// float                          PlayRate                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   StartSection                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          StartPos                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bOnlyJumpToSectionWhilePlaying (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   IgnoreStopSection              (Parm, ZeroConstructor, IsPlainOldData)

void UCharMainMCAnimInstance::HandlePlayerAnimMontagePlayExtraDelegate(class UAnimMontage* MontageToPlay, bool bWantsPlay, float PlayRate, const struct FName& StartSection, float StartPos, bool bOnlyJumpToSectionWhilePlaying, const struct FName& IgnoreStopSection)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharMainMCAnimInstance.HandlePlayerAnimMontagePlayExtraDelegate");

	UCharMainMCAnimInstance_HandlePlayerAnimMontagePlayExtraDelegate_Params params;
	params.MontageToPlay = MontageToPlay;
	params.bWantsPlay = bWantsPlay;
	params.PlayRate = PlayRate;
	params.StartSection = StartSection;
	params.StartPos = StartPos;
	params.bOnlyJumpToSectionWhilePlaying = bOnlyJumpToSectionWhilePlaying;
	params.IgnoreStopSection = IgnoreStopSection;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharMainMCAnimInstance.HandlePlayerAnimMontagePlayDelegate
// (Final, Native, Public)
// Parameters:
// class UAnimMontage*            MontageToPlay                  (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bWantsPlay                     (Parm, ZeroConstructor, IsPlainOldData)
// float                          PlayRate                       (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   StartSection                   (Parm, ZeroConstructor, IsPlainOldData)
// float                          StartPos                       (Parm, ZeroConstructor, IsPlainOldData)

void UCharMainMCAnimInstance::HandlePlayerAnimMontagePlayDelegate(class UAnimMontage* MontageToPlay, bool bWantsPlay, float PlayRate, const struct FName& StartSection, float StartPos)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharMainMCAnimInstance.HandlePlayerAnimMontagePlayDelegate");

	UCharMainMCAnimInstance_HandlePlayerAnimMontagePlayDelegate_Params params;
	params.MontageToPlay = MontageToPlay;
	params.bWantsPlay = bWantsPlay;
	params.PlayRate = PlayRate;
	params.StartSection = StartSection;
	params.StartPos = StartPos;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.CharMainMCAnimInstance.HandleAnimPlaySlotAnimDelegate
// (Final, Native, Public)
// Parameters:
// class UAnimSequenceBase*       AnimSequence                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bWantsPlay                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   SlotName                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          PlayRate                       (Parm, ZeroConstructor, IsPlainOldData)
// float                          BlendTime                      (Parm, ZeroConstructor, IsPlainOldData)
// unsigned char                  InLoopCount                    (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          InStartPos                     (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
// float                          LoopStartPos                   (ConstParm, Parm, ZeroConstructor, IsPlainOldData)

void UCharMainMCAnimInstance::HandleAnimPlaySlotAnimDelegate(class UAnimSequenceBase* AnimSequence, bool bWantsPlay, const struct FName& SlotName, float PlayRate, float BlendTime, unsigned char InLoopCount, float InStartPos, float LoopStartPos)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.CharMainMCAnimInstance.HandleAnimPlaySlotAnimDelegate");

	UCharMainMCAnimInstance_HandleAnimPlaySlotAnimDelegate_Params params;
	params.AnimSequence = AnimSequence;
	params.bWantsPlay = bWantsPlay;
	params.SlotName = SlotName;
	params.PlayRate = PlayRate;
	params.BlendTime = BlendTime;
	params.InLoopCount = InLoopCount;
	params.InStartPos = InStartPos;
	params.LoopStartPos = LoopStartPos;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCityGameMode.ReplayRecoverGenerateDSCheckpoint
// (Final, Native, Public)
// Parameters:
// struct FString                 InReplayName                   (Parm, ZeroConstructor)

void AMainCityGameMode::ReplayRecoverGenerateDSCheckpoint(const struct FString& InReplayName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCityGameMode.ReplayRecoverGenerateDSCheckpoint");

	AMainCityGameMode_ReplayRecoverGenerateDSCheckpoint_Params params;
	params.InReplayName = InReplayName;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCityGameMode.PreInitGameState
// (Native, Event, Public, BlueprintEvent)

void AMainCityGameMode::PreInitGameState()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCityGameMode.PreInitGameState");

	AMainCityGameMode_PreInitGameState_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCityGameMode.InitConsoleVar
// (Final, Native, Public)
// Parameters:
// struct FString                 Command                        (Parm, ZeroConstructor)

void AMainCityGameMode::InitConsoleVar(const struct FString& Command)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCityGameMode.InitConsoleVar");

	AMainCityGameMode_InitConsoleVar_Params params;
	params.Command = Command;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCityGameMode.GenReplayDone
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 ErrorMsg                       (Parm, ZeroConstructor)

void AMainCityGameMode::GenReplayDone(const struct FString& ErrorMsg)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCityGameMode.GenReplayDone");

	AMainCityGameMode_GenReplayDone_Params params;
	params.ErrorMsg = ErrorMsg;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCityGameMode.DSPlayerKickOut
// (Final, Native, Public)
// Parameters:
// uint64_t                       UID                            (Parm, ZeroConstructor, IsPlainOldData)
// struct FName                   PlayerType                     (Parm, ZeroConstructor, IsPlainOldData)
// struct FString                 ExitReason                     (Parm, ZeroConstructor)

void AMainCityGameMode::DSPlayerKickOut(uint64_t UID, const struct FName& PlayerType, const struct FString& ExitReason)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCityGameMode.DSPlayerKickOut");

	AMainCityGameMode_DSPlayerKickOut_Params params;
	params.UID = UID;
	params.PlayerType = PlayerType;
	params.ExitReason = ExitReason;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCityGameplayStatics.GetProjectSavedDir
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// struct FString                 ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

struct FString UMainCityGameplayStatics::GetProjectSavedDir()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCityGameplayStatics.GetProjectSavedDir");

	UMainCityGameplayStatics_GetProjectSavedDir_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function MainCity.MainCityHelper.SetSwapRolesForReplay
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class AActor*                  InActor                        (Parm, ZeroConstructor, IsPlainOldData)
// int                            ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

int UMainCityHelper::SetSwapRolesForReplay(class AActor* InActor)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCityHelper.SetSwapRolesForReplay");

	UMainCityHelper_SetSwapRolesForReplay_Params params;
	params.InActor = InActor;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function MainCity.MainCityPlayerState.RefreshAliasInfo
// (Final, Native, Public, HasOutParms, BlueprintCallable)
// Parameters:
// struct FGameModePlayerAliasInfo PlayerAliasInfo                (Parm, OutParm)

void AMainCityPlayerState::RefreshAliasInfo(struct FGameModePlayerAliasInfo* PlayerAliasInfo)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCityPlayerState.RefreshAliasInfo");

	AMainCityPlayerState_RefreshAliasInfo_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	if (PlayerAliasInfo != nullptr)
		*PlayerAliasInfo = params.PlayerAliasInfo;
}


// Function MainCity.MainCitySeesawAnimInstance.SyncAttachedActorAnimation
// (Final, Native, Public, BlueprintCallable)

void UMainCitySeesawAnimInstance::SyncAttachedActorAnimation()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySeesawAnimInstance.SyncAttachedActorAnimation");

	UMainCitySeesawAnimInstance_SyncAttachedActorAnimation_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.SetHasInitLobbyAvatar
// (Final, Native, Public)
// Parameters:
// class ASTExtraPlayerController* InController                   (Parm, ZeroConstructor, IsPlainOldData)
// bool                           bInValue                       (Parm, ZeroConstructor, IsPlainOldData)

void UMainCitySubsystem::SetHasInitLobbyAvatar(class ASTExtraPlayerController* InController, bool bInValue)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.SetHasInitLobbyAvatar");

	UMainCitySubsystem_SetHasInitLobbyAvatar_Params params;
	params.InController = InController;
	params.bInValue = bInValue;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.ResetMainCityGameState
// (Final, Native, Public, BlueprintCallable)
// Parameters:
// class ASTExtraGameStateBase*   InGameState                    (Parm, ZeroConstructor, IsPlainOldData)

void UMainCitySubsystem::ResetMainCityGameState(class ASTExtraGameStateBase* InGameState)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.ResetMainCityGameState");

	UMainCitySubsystem_ResetMainCityGameState_Params params;
	params.InGameState = InGameState;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.PreShutdownUnrealNetwork
// (Native, Event, Public, BlueprintEvent)

void UMainCitySubsystem::PreShutdownUnrealNetwork()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.PreShutdownUnrealNetwork");

	UMainCitySubsystem_PreShutdownUnrealNetwork_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.PreEnterMainCityBattle
// (Native, Event, Public, BlueprintEvent)

void UMainCitySubsystem::PreEnterMainCityBattle()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.PreEnterMainCityBattle");

	UMainCitySubsystem_PreEnterMainCityBattle_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.PostShutdownUnrealNetwork
// (Native, Event, Public, BlueprintEvent)

void UMainCitySubsystem::PostShutdownUnrealNetwork()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.PostShutdownUnrealNetwork");

	UMainCitySubsystem_PostShutdownUnrealNetwork_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.PostPlayerActorChannelOpen
// (Native, Event, Public, BlueprintEvent)

void UMainCitySubsystem::PostPlayerActorChannelOpen()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.PostPlayerActorChannelOpen");

	UMainCitySubsystem_PostPlayerActorChannelOpen_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.PostInitialize
// (Native, Event, Public, BlueprintEvent)

void UMainCitySubsystem::PostInitialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.PostInitialize");

	UMainCitySubsystem_PostInitialize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.PostEnterMainCityBattle
// (Native, Event, Public, BlueprintEvent)

void UMainCitySubsystem::PostEnterMainCityBattle()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.PostEnterMainCityBattle");

	UMainCitySubsystem_PostEnterMainCityBattle_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.PostDeinitialize
// (Native, Event, Public, BlueprintEvent)

void UMainCitySubsystem::PostDeinitialize()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.PostDeinitialize");

	UMainCitySubsystem_PostDeinitialize_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.PostClearActors
// (Native, Event, Public, BlueprintEvent)

void UMainCitySubsystem::PostClearActors()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.PostClearActors");

	UMainCitySubsystem_PostClearActors_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.KeepActor
// (Final, Native, Public)
// Parameters:
// class AActor*                  InActor                        (Parm, ZeroConstructor, IsPlainOldData)

void UMainCitySubsystem::KeepActor(class AActor* InActor)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.KeepActor");

	UMainCitySubsystem_KeepActor_Params params;
	params.InActor = InActor;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.MainCitySubsystem.InitStandalonePawn
// (Final, Native, Public, HasOutParms, HasDefaults)
// Parameters:
// class UClass*                  InClass                        (Parm, ZeroConstructor, IsPlainOldData)
// struct FVector                 InLocation                     (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// struct FRotator                InRotation                     (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
// class ASTExtraBaseCharacter*   ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

class ASTExtraBaseCharacter* UMainCitySubsystem::InitStandalonePawn(class UClass* InClass, const struct FVector& InLocation, const struct FRotator& InRotation)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.InitStandalonePawn");

	UMainCitySubsystem_InitStandalonePawn_Params params;
	params.InClass = InClass;
	params.InLocation = InLocation;
	params.InRotation = InRotation;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function MainCity.MainCitySubsystem.ClearActors
// (Final, Native, Public)

void UMainCitySubsystem::ClearActors()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.MainCitySubsystem.ClearActors");

	UMainCitySubsystem_ClearActors_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.WriteLuaInfo
// (Final, Native, Public, HasOutParms)
// Parameters:
// TArray<unsigned char>          InData                         (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)

void UReplayRecoverSubsystem::WriteLuaInfo(TArray<unsigned char> InData)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.WriteLuaInfo");

	UReplayRecoverSubsystem_WriteLuaInfo_Params params;
	params.InData = InData;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.SetReplayName
// (Final, Native, Public)
// Parameters:
// struct FString                 InReplayName                   (Parm, ZeroConstructor)

void UReplayRecoverSubsystem::SetReplayName(const struct FString& InReplayName)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.SetReplayName");

	UReplayRecoverSubsystem_SetReplayName_Params params;
	params.InReplayName = InReplayName;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.ReadLuaInfo
// (Final, Native, Public)
// Parameters:
// TArray<unsigned char>          ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm)

TArray<unsigned char> UReplayRecoverSubsystem::ReadLuaInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.ReadLuaInfo");

	UReplayRecoverSubsystem_ReadLuaInfo_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function MainCity.ReplayRecoverSubsystem.PreInitializeWithParams
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class UWorld*                  InWorld                        (Parm, ZeroConstructor, IsPlainOldData)
// class UNetDriver*              InDriver                       (Parm, ZeroConstructor, IsPlainOldData)

void UReplayRecoverSubsystem::PreInitializeWithParams(class UWorld* InWorld, class UNetDriver* InDriver)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.PreInitializeWithParams");

	UReplayRecoverSubsystem_PreInitializeWithParams_Params params;
	params.InWorld = InWorld;
	params.InDriver = InDriver;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.PreInitializeForWorld
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 InURLStr                       (Parm, ZeroConstructor)
// class UWorld*                  InWorld                        (Parm, ZeroConstructor, IsPlainOldData)
// class USTExtraGameInstance*    InGameInstance                 (Parm, ZeroConstructor, IsPlainOldData)

void UReplayRecoverSubsystem::PreInitializeForWorld(const struct FString& InURLStr, class UWorld* InWorld, class USTExtraGameInstance* InGameInstance)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.PreInitializeForWorld");

	UReplayRecoverSubsystem_PreInitializeForWorld_Params params;
	params.InURLStr = InURLStr;
	params.InWorld = InWorld;
	params.InGameInstance = InGameInstance;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.PreInitializeForGameMode
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 InURLStr                       (Parm, ZeroConstructor)
// class UWorld*                  InWorld                        (Parm, ZeroConstructor, IsPlainOldData)
// class AGameStateBase*          InGameState                    (Parm, ZeroConstructor, IsPlainOldData)

void UReplayRecoverSubsystem::PreInitializeForGameMode(const struct FString& InURLStr, class UWorld* InWorld, class AGameStateBase* InGameState)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.PreInitializeForGameMode");

	UReplayRecoverSubsystem_PreInitializeForGameMode_Params params;
	params.InURLStr = InURLStr;
	params.InWorld = InWorld;
	params.InGameState = InGameState;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.PreDemoPlaybackEnded
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class UWorld*                  InWorld                        (Parm, ZeroConstructor, IsPlainOldData)

void UReplayRecoverSubsystem::PreDemoPlaybackEnded(class UWorld* InWorld)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.PreDemoPlaybackEnded");

	UReplayRecoverSubsystem_PreDemoPlaybackEnded_Params params;
	params.InWorld = InWorld;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.PostInitializeWithParams
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// class UWorld*                  InWorld                        (Parm, ZeroConstructor, IsPlainOldData)
// class UNetDriver*              InDriver                       (Parm, ZeroConstructor, IsPlainOldData)

void UReplayRecoverSubsystem::PostInitializeWithParams(class UWorld* InWorld, class UNetDriver* InDriver)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.PostInitializeWithParams");

	UReplayRecoverSubsystem_PostInitializeWithParams_Params params;
	params.InWorld = InWorld;
	params.InDriver = InDriver;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.PostInitializeForWorld
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 InURLStr                       (Parm, ZeroConstructor)
// class UWorld*                  InWorld                        (Parm, ZeroConstructor, IsPlainOldData)
// class USTExtraGameInstance*    InGameInstance                 (Parm, ZeroConstructor, IsPlainOldData)

void UReplayRecoverSubsystem::PostInitializeForWorld(const struct FString& InURLStr, class UWorld* InWorld, class USTExtraGameInstance* InGameInstance)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.PostInitializeForWorld");

	UReplayRecoverSubsystem_PostInitializeForWorld_Params params;
	params.InURLStr = InURLStr;
	params.InWorld = InWorld;
	params.InGameInstance = InGameInstance;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.PostInitializeForGameMode
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 InURLStr                       (Parm, ZeroConstructor)
// class UWorld*                  InWorld                        (Parm, ZeroConstructor, IsPlainOldData)
// class AGameStateBase*          InGameState                    (Parm, ZeroConstructor, IsPlainOldData)

void UReplayRecoverSubsystem::PostInitializeForGameMode(const struct FString& InURLStr, class UWorld* InWorld, class AGameStateBase* InGameState)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.PostInitializeForGameMode");

	UReplayRecoverSubsystem_PostInitializeForGameMode_Params params;
	params.InURLStr = InURLStr;
	params.InWorld = InWorld;
	params.InGameState = InGameState;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.LuaSaveLuaInfo
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UReplayRecoverSubsystem::LuaSaveLuaInfo()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.LuaSaveLuaInfo");

	UReplayRecoverSubsystem_LuaSaveLuaInfo_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function MainCity.ReplayRecoverSubsystem.LoadReplayDone
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 ErrorMsg                       (Parm, ZeroConstructor)

void UReplayRecoverSubsystem::LoadReplayDone(const struct FString& ErrorMsg)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.LoadReplayDone");

	UReplayRecoverSubsystem_LoadReplayDone_Params params;
	params.ErrorMsg = ErrorMsg;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.IsVersionValid
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 RecordVersion                  (Parm, ZeroConstructor)
// struct FString                 PlayerVersion                  (Parm, ZeroConstructor)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UReplayRecoverSubsystem::IsVersionValid(const struct FString& RecordVersion, const struct FString& PlayerVersion)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.IsVersionValid");

	UReplayRecoverSubsystem_IsVersionValid_Params params;
	params.RecordVersion = RecordVersion;
	params.PlayerVersion = PlayerVersion;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function MainCity.ReplayRecoverSubsystem.IsTimeValid
// (Final, Native, Public)
// Parameters:
// int64_t                        RecordTime                     (Parm, ZeroConstructor, IsPlainOldData)
// int64_t                        PlayTime                       (Parm, ZeroConstructor, IsPlainOldData)
// bool                           ReturnValue                    (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)

bool UReplayRecoverSubsystem::IsTimeValid(int64_t RecordTime, int64_t PlayTime)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.IsTimeValid");

	UReplayRecoverSubsystem_IsTimeValid_Params params;
	params.RecordTime = RecordTime;
	params.PlayTime = PlayTime;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


// Function MainCity.ReplayRecoverSubsystem.GenReplayDone
// (Native, Event, Public, BlueprintEvent)
// Parameters:
// struct FString                 ErrorMsg                       (Parm, ZeroConstructor)

void UReplayRecoverSubsystem::GenReplayDone(const struct FString& ErrorMsg)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.GenReplayDone");

	UReplayRecoverSubsystem_GenReplayDone_Params params;
	params.ErrorMsg = ErrorMsg;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.DeleteExpiredFiles
// (Final, Native, Public)
// Parameters:
// float                          MaxKeepHours                   (Parm, ZeroConstructor, IsPlainOldData)

void UReplayRecoverSubsystem::DeleteExpiredFiles(float MaxKeepHours)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.DeleteExpiredFiles");

	UReplayRecoverSubsystem_DeleteExpiredFiles_Params params;
	params.MaxKeepHours = MaxKeepHours;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function MainCity.ReplayRecoverSubsystem.ClearRecoverFile
// (Final, Native, Public)

void UReplayRecoverSubsystem::ClearRecoverFile()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function MainCity.ReplayRecoverSubsystem.ClearRecoverFile");

	UReplayRecoverSubsystem_ClearRecoverFile_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

