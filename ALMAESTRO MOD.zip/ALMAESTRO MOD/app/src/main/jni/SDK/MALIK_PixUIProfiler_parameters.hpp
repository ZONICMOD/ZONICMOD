#pragma once

// PUBG MOBILE (3.9.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Mon Jul  7 13:18:15 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function PixUIProfiler.PxProfilerMgr.SetPrintSizeChange
struct UPxProfilerMgr_SetPrintSizeChange_Params
{
	bool                                               bPrintSizeChange;                                         // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PixUIProfiler.PxProfilerMgr.SetPrintCountChange
struct UPxProfilerMgr_SetPrintCountChange_Params
{
	bool                                               bPrintCountChange;                                        // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function PixUIProfiler.PxProfilerMgr.Print
struct UPxProfilerMgr_Print_Params
{
};

// Function PixUIProfiler.PxProfilerMgr.Check
struct UPxProfilerMgr_Check_Params
{
};

// Function PixUIProfiler.PxProfilerMgr.BePrintSizeChange
struct UPxProfilerMgr_BePrintSizeChange_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function PixUIProfiler.PxProfilerMgr.BePrintCountChange
struct UPxProfilerMgr_BePrintCountChange_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

