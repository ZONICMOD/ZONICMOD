#pragma once

// PUBG MOBILE (3.9.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Mon Jul  7 13:18:14 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class MainCity.CarryBackMCAnimInstance
// 0x0040 (0x0890 - 0x0850)
class UCarryBackMCAnimInstance : public UCharacterAnimStateBase
{
public:
	class UBlendSpace*                                 BS_beCarryBackMove;                                       // 0x0850(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	ECarryBackAnimState                                CurrentCarryBackState;                                    // 0x0854(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x7];                                       // 0x0855(0x0007) MISSED OFFSET
	float                                              CarryBackTimeAccumulator;                                 // 0x085C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bCarryBackState;                                          // 0x0860(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bBeCarryBackState;                                        // 0x0861(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0862(0x0002) MISSED OFFSET
	int                                                SubStateID;                                               // 0x0864(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class ASTExtraBaseCharacter*                       AttachParentCharacter;                                    // 0x0868(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     AttachParentPawnMoveVelocity;                             // 0x086C(0x000C) (BlueprintVisible, IsPlainOldData)
	struct FVector                                     PreAnimVelocity;                                          // 0x0878(0x000C) (BlueprintVisible, IsPlainOldData)
	class USTExtraAnimInstanceBase*                    MainInstance;                                             // 0x0884(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x8];                                       // 0x0888(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.CarryBackMCAnimInstance");
		return pStaticClass;
	}


	void HandlePlayerPoseChange(TEnumAsByte<ESTEPoseState> LastPose, TEnumAsByte<ESTEPoseState> NewPose);
};


// Class MainCity.CharLocomotionMCAnimInstance
// 0x01D0 (0x0A20 - 0x0850)
class UCharLocomotionMCAnimInstance : public UCharacterAnimStateBase
{
public:
	class UBlendSpace*                                 BS_MovementCrouch;                                        // 0x0850(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UBlendSpace*                                 BS_MovementProne;                                         // 0x0854(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBlendSpace*                                 BS_MovementStandDest;                                     // 0x0858(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UBlendSpace*                                 BS_MovementCrouchDest;                                    // 0x085C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UBlendSpace*                                 BS_MovementProneDest;                                     // 0x0860(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_StandScopeBlend;                                       // 0x0864(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_CrouchScopeBlend;                                      // 0x0868(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TMap<struct FName, float>                          MovementStand_SourceTransTime;                            // 0x086C(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	TMap<struct FName, float>                          MovementStand_DestTransTime;                              // 0x08A8(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	TMap<TEnumAsByte<ECustomMovmentMode>, float>       CustomMovement_BlendTime;                                 // 0x08E4(0x0050) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance)
	class UAnimSequence*                               AS_SwitchPose_StandToCrouch;                              // 0x0920(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_StandToProne;                               // 0x0924(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_CrouchToStand;                              // 0x0928(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_CrouchToProne;                              // 0x092C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_ProneToStand;                               // 0x0930(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_ProneToCrouch;                              // 0x0934(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_StandToCrouchDest;                          // 0x0938(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_StandToProneDest;                           // 0x093C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_CrouchToStandDest;                          // 0x0940(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_CrouchToProneDest;                          // 0x0944(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_ProneToStandDest;                           // 0x0948(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               AS_SwitchPose_ProneToCrouchDest;                          // 0x094C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     moveVelocity;                                             // 0x0950(0x000C) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	TEnumAsByte<ECharacterPoseType>                    PoseType;                                                 // 0x095C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EWeaponType>                           WeaponType;                                               // 0x095D(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ECharacterPoseType>                    InterruptCachePose;                                       // 0x095E(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ECharacterPoseType>                    RecoverCharPose;                                          // 0x095F(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x8];                                       // 0x0960(0x0008) MISSED OFFSET
	bool                                               bIsOnVehicle;                                             // 0x0968(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bScoping;                                                 // 0x0969(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bIsMoving;                                                // 0x096A(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bMovementChanged;                                         // 0x096B(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1];                                       // 0x096C(0x0001) MISSED OFFSET
	bool                                               bMovementChangedAndNotSwitchingPose;                      // 0x096D(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x1];                                       // 0x096E(0x0001) MISSED OFFSET
	bool                                               bWithoutWeapon;                                           // 0x096F(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bIsSwitchingPose;                                         // 0x0970(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bUseInterruptPose;                                        // 0x0971(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bEmptyToCrouch;                                           // 0x0972(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bEmptyToProne;                                            // 0x0973(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bEmptyToStand;                                            // 0x0974(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bStandToProne;                                            // 0x0975(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bStandToCrouchNotMove;                                    // 0x0976(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bStandToCrouchMove;                                       // 0x0977(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bStandTo_StandToProne;                                    // 0x0978(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bStandTo_StandToCrouch;                                   // 0x0979(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCrouchToProne;                                           // 0x097A(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCrouchToStandNotMove;                                    // 0x097B(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCrouchToStandMove;                                       // 0x097C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCrouchTo_CrouchToProne;                                  // 0x097D(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCrouchTo_CrouchToStand;                                  // 0x097E(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bProneToStand;                                            // 0x097F(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bProneToCrouch;                                           // 0x0980(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bProneTo_ProneToCrouch;                                   // 0x0981(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bProneTo_ProneToStand;                                    // 0x0982(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bProneToStand_ToStand;                                    // 0x0983(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bStandToProne_ToProne;                                    // 0x0984(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCrouchToProne_ToProne;                                   // 0x0985(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bProneToCrouch_ToCrouch;                                  // 0x0986(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x1];                                       // 0x0987(0x0001) MISSED OFFSET
	float                                              StandSwitchToPronePoseAnimDuration;                       // 0x0988(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              StandSwitchFromPronePoseAnimDuration;                     // 0x098C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              CrouchSwitchToPronePoseAnimDuration;                      // 0x0990(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              CrouchSwitchFromPronePoseAnimDuration;                    // 0x0994(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              StandSwitchToPronePoseAnimDelay;                          // 0x0998(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              StandSwitchFromPronePoseAnimDelay;                        // 0x099C(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              CrouchSwitchToPronePoseAnimDelay;                         // 0x09A0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              CrouchSwitchFromPronePoseAnimDelay;                       // 0x09A4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              MovementBlendTime;                                        // 0x09A8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              SwitchPoseTransTime;                                      // 0x09AC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              SwitchingPoseTimer;                                       // 0x09B0(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              SwitchingPoseTimerInternal;                               // 0x09B4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              InterruptPoseInternal;                                    // 0x09B8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              SwitchPoseAnimStartPosition;                              // 0x09BC(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	float                                              CustomMovementBlendTime;                                  // 0x09C0(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              ScopeVelocityInterpSpeed;                                 // 0x09C4(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              SprintToPronePlayRate;                                    // 0x09C8(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bCarryBackState;                                          // 0x09CC(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x7];                                       // 0x09CD(0x0007) MISSED OFFSET
	float                                              CarryBackTimeAccumulator;                                 // 0x09D4(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TArray<struct FCharacterViewPointConfig>           PoseStatusViewPointConfig;                                // 0x09D8(0x000C) (Edit, ZeroConstructor, DisableEditOnInstance)
	unsigned char                                      UnknownData05[0x14];                                      // 0x09E4(0x0014) MISSED OFFSET
	float                                              LeaveStateTimerInternal;                                  // 0x09F8(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              GunSprintToProneDefaultPlayRate;                          // 0x09FC(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              CommonSprintToProneDefaultPlayRate;                       // 0x0A00(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData06[0x4];                                       // 0x0A04(0x0004) MISSED OFFSET
	struct FName                                       JumpProneBlendCurveName;                                  // 0x0A08(0x0008) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class USTExtraAnimInstanceBase*                    MainInstance;                                             // 0x0A10(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData07[0xC];                                       // 0x0A14(0x000C) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.CharLocomotionMCAnimInstance");
		return pStaticClass;
	}


	void SwitchingPoseFinishCallback();
	void SetViewPointLimitByPoseStatus(ECharacterAnimBlendPoseType InPoseType, bool bEnter);
	void SetInterruptPose(bool bUseInterruptPose, TEnumAsByte<ECharacterPoseType> InterruptPose);
	void LeaveStateCallback();
	void HandleStateLeave(EPawnState LeaveState);
	void HandlePlayerPoseChange(TEnumAsByte<ESTEPoseState> LastPose, TEnumAsByte<ESTEPoseState> NewPose);
};


// Class MainCity.CharMainMCAnimInstance
// 0x00A0 (0x08F0 - 0x0850)
class UCharMainMCAnimInstance : public UCharacterAnimStateBase
{
public:
	class UAnimSequence*                               C_JumpStart;                                              // 0x0850(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               C_LandLight;                                              // 0x0854(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               C_LandHeavy;                                              // 0x0858(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	class UBlendSpace1D*                               C_FallingBS;                                              // 0x085C(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bUseCustomBS;                                             // 0x0860(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0861(0x0003) MISSED OFFSET
	class UAnimSequence*                               C_JumpCustom;                                             // 0x0864(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBlendSpace1D*                               C_FallingCustom;                                          // 0x0868(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_Scoping;                                                // 0x086C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x086D(0x0003) MISSED OFFSET
	float                                              C_CharacterYawRotateRate;                                 // 0x0870(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              C_CharacterYawRotateRate_Reverse;                         // 0x0874(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              ScopeVelocityInterpSpeed;                                 // 0x0878(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              b_WalkAdditiveAlpha;                                      // 0x087C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               b_UnarmedFallingToRifleFallLandingHard;                   // 0x0880(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               b_WalkToRifleJumpStationStart;                            // 0x0881(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               C_IdleAddtiveValid;                                       // 0x0882(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               C_ShouldPauseAnim;                                        // 0x0883(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bWalkToJumpStart;                                         // 0x0884(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               C_Move;                                                   // 0x0885(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x0886(0x0002) MISSED OFFSET
	struct FVector                                     C_MoveVelocity;                                           // 0x0888(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	float                                              f_C_MoveVelocityLengthSquard;                             // 0x0894(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<EWeaponType>                           C_WeaponType;                                             // 0x0898(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               b_C_LastMovementMode_NEQ_Falling_OR_HoldGrenade;          // 0x0899(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               b_WalkToUnarmedFalling;                                   // 0x089A(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               b_UnarmedFallingToRifleCombatFallLanding;                 // 0x089B(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              f_FallingVelocityZFactor;                                 // 0x089C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              f_C_MoveVelocity_X_FallingZFactor;                        // 0x08A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              C_MaxFallingSpeed;                                        // 0x08A4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               MovingOnGround;                                           // 0x08A8(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_MovingOnGroundAndMovbale;                               // 0x08A9(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ECharacterPoseType>                    C_PoseType;                                               // 0x08AA(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	TEnumAsByte<EMovementMode>                         C_LastMovementMode;                                       // 0x08AB(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               C_IsJumping;                                              // 0x08AC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIsLandingHard;                                           // 0x08AD(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bAlwaysLandLight;                                         // 0x08AE(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x1];                                       // 0x08AF(0x0001) MISSED OFFSET
	struct FVector                                     moveVelocity;                                             // 0x08B0(0x000C) (BlueprintVisible, BlueprintReadOnly, IsPlainOldData)
	bool                                               C_ClimbAnimSwitch;                                        // 0x08BC(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x3];                                       // 0x08BD(0x0003) MISSED OFFSET
	float                                              C_ClimbAnimTransTime;                                     // 0x08C0(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              C_ClimbAnimTime_A;                                        // 0x08C4(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              C_ClimbAnimTime_B;                                        // 0x08C8(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimSequence*                               C_Climb_FrameAnim_A;                                      // 0x08CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UAnimSequence*                               C_Climb_FrameAnim_B;                                      // 0x08D0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               C_PlayerUseSeesaw;                                        // 0x08D4(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bIsLinkMotionLayer;                                       // 0x08D5(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x2];                                       // 0x08D6(0x0002) MISSED OFFSET
	struct FName                                       LinkMotionLayerTagName;                                   // 0x08D8(0x0008) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               bHasCarryBacK;                                            // 0x08E0(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ECustomMovmentMode>                    C_CustomMovementMode;                                     // 0x08E1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData06[0x2];                                       // 0x08E2(0x0002) MISSED OFFSET
	class USTExtraAnimInstanceBase*                    MainInstance;                                             // 0x08E4(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UAnimInstanceContainer*                      LocomotionAnimContainer;                                  // 0x08E8(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, Transient, IsPlainOldData)
	class UClass*                                      TargetLocomotionBP;                                       // 0x08EC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.CharMainMCAnimInstance");
		return pStaticClass;
	}


	void SetClimbAnimation(class UAnimSequence* AnimSequence, bool bFlag);
	void HandlePlayerAnimMontagePlayExtraDelegate(class UAnimMontage* MontageToPlay, bool bWantsPlay, float PlayRate, const struct FName& StartSection, float StartPos, bool bOnlyJumpToSectionWhilePlaying, const struct FName& IgnoreStopSection);
	void HandlePlayerAnimMontagePlayDelegate(class UAnimMontage* MontageToPlay, bool bWantsPlay, float PlayRate, const struct FName& StartSection, float StartPos);
	void HandleAnimPlaySlotAnimDelegate(class UAnimSequenceBase* AnimSequence, bool bWantsPlay, const struct FName& SlotName, float PlayRate, float BlendTime, unsigned char InLoopCount, float InStartPos, float LoopStartPos);
};


// Class MainCity.CharSeesawMCAnimInstance
// 0x0020 (0x09F0 - 0x09D0)
class UCharSeesawMCAnimInstance : public USTExtraAnimInstanceBase
{
public:
	bool                                               C_IsActivate;                                             // 0x09D0(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_IsLooping;                                              // 0x09D1(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x2];                                       // 0x09D2(0x0002) MISSED OFFSET
	int                                                C_CurSeatState;                                           // 0x09D4(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                C_OtherSeatState;                                         // 0x09D8(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                C_SeesawState;                                            // 0x09DC(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_SitAtA;                                                 // 0x09E0(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_SelfKnockUp;                                            // 0x09E1(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_OtherKnockUp;                                           // 0x09E2(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_SelfIdle;                                               // 0x09E3(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_SelfWaiting;                                            // 0x09E4(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_SelfEntering;                                           // 0x09E5(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_SelfEntered;                                            // 0x09E6(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_SelfExiting;                                            // 0x09E7(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_OtherIdle;                                              // 0x09E8(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_OtherWaiting;                                           // 0x09E9(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_OtherEntering;                                          // 0x09EA(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_OtherEntered;                                           // 0x09EB(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_OtherExiting;                                           // 0x09EC(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_IsEnterField;                                           // 0x09ED(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_IsInGame;                                               // 0x09EE(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_IsSpeedUp;                                              // 0x09EF(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.CharSeesawMCAnimInstance");
		return pStaticClass;
	}

};


// Class MainCity.FollowerSysDataAsset
// 0x0070 (0x0090 - 0x0020)
class UFollowerSysDataAsset : public UDataAsset
{
public:
	struct FName                                       HandHoldingSocket;                                        // 0x0020(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     HandHoldingSocketLocOffset;                               // 0x0028(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FRotator                                    HandHoldingSocketRotOffset;                               // 0x0034(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              PullW;                                                    // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               NormalizePull;                                            // 0x0044(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0045(0x0003) MISSED OFFSET
	struct FVector                                     PositivePullFactor;                                       // 0x0048(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     NegativePullFactor;                                       // 0x0054(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               RotateBone;                                               // 0x0060(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               RotateLimb;                                               // 0x0061(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x0062(0x0002) MISSED OFFSET
	float                                              DeltaSmoothSpeed;                                         // 0x0064(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AngularDeltaSmoothSpeed;                                  // 0x0068(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              OffsetSoverParms1;                                        // 0x006C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              TargetLocLerpSpeed;                                       // 0x0070(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               SmoothPositionOverTime;                                   // 0x0074(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x3];                                       // 0x0075(0x0003) MISSED OFFSET
	float                                              MaxPositionSpeed;                                         // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxPositionDistance;                                      // 0x007C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               SmoothRotationOverTime;                                   // 0x0080(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x0081(0x0003) MISSED OFFSET
	float                                              MaxDegreesSpeed;                                          // 0x0084(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              MaxDegreesDistance;                                       // 0x0088(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x4];                                       // 0x008C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.FollowerSysDataAsset");
		return pStaticClass;
	}

};


// Class MainCity.HoldingHandsMCAnimInstance
// 0x00B0 (0x0900 - 0x0850)
class UHoldingHandsMCAnimInstance : public UCharacterAnimStateBase
{
public:
	class UBlendSpace*                                 BS_HoldingHoldsFollower;                                  // 0x0850(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FVector                                     HoldingHandsTargetLoc;                                    // 0x0854(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FRotator                                    HoldingHandsTargetRot;                                    // 0x0860(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     LeaderHoldingHandsTargetLoc;                              // 0x086C(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	struct FVector                                     FollowerHoldingHandsTargetLoc;                            // 0x0878(0x000C) (Edit, BlueprintVisible, DisableEditOnInstance, IsPlainOldData)
	bool                                               bIsFollower;                                              // 0x0884(0x0001) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0885(0x0003) MISSED OFFSET
	struct FVector                                     OffsetSover1;                                             // 0x0888(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	float                                              OffsetSoverParms1;                                        // 0x0894(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UFollowerSysDataAsset*                       FollowerDA;                                               // 0x0898(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	class UFollowerSysDataAsset*                       LeaderDA;                                                 // 0x089C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	float                                              PullW;                                                    // 0x08A0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               NormalizePull;                                            // 0x08A4(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x08A5(0x0003) MISSED OFFSET
	struct FVector                                     PositivePullFactor;                                       // 0x08A8(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     NegativePullFactor;                                       // 0x08B4(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               RotateBone;                                               // 0x08C0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               RotateLimb;                                               // 0x08C1(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x08C2(0x0002) MISSED OFFSET
	float                                              DeltaSmoothSpeed;                                         // 0x08C4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              AngularDeltaSmoothSpeed;                                  // 0x08C8(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              F_PullW;                                                  // 0x08CC(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               F_NormalizePull;                                          // 0x08D0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x3];                                       // 0x08D1(0x0003) MISSED OFFSET
	struct FVector                                     F_PositivePullFactor;                                     // 0x08D4(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	struct FVector                                     F_NegativePullFactor;                                     // 0x08E0(0x000C) (Edit, BlueprintVisible, IsPlainOldData)
	bool                                               F_RotateBone;                                             // 0x08EC(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               F_RotateLimb;                                             // 0x08ED(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x2];                                       // 0x08EE(0x0002) MISSED OFFSET
	float                                              F_DeltaSmoothSpeed;                                       // 0x08F0(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              F_AngularDeltaSmoothSpeed;                                // 0x08F4(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ECharacterFollowType>                  FollowType;                                               // 0x08F8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EHoldingHandsIKMode>                   EHandIKMode;                                              // 0x08F9(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x6];                                       // 0x08FA(0x0006) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.HoldingHandsMCAnimInstance");
		return pStaticClass;
	}

};


// Class MainCity.MainCityGameMode
// 0x0060 (0x1888 - 0x1828)
class AMainCityGameMode : public ABattleRoyaleGameMode
{
public:
	unsigned char                                      UnknownData00[0x3C];                                      // 0x1828(0x003C) MISSED OFFSET
	uint32_t                                           MaxAcceptOneFrame;                                        // 0x1864(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              MinAcceptTimeDelta;                                       // 0x1868(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              UpdateDistTimeDelta;                                      // 0x186C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	TArray<float>                                      RelevantDistArray;                                        // 0x1870(0x000C) (ZeroConstructor, Config)
	float                                              TickTimeDelta;                                            // 0x187C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              RelevantDataLifeTime;                                     // 0x1880(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	float                                              ForceRelevantTimeDelta;                                   // 0x1884(0x0004) (ZeroConstructor, Config, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCityGameMode");
		return pStaticClass;
	}


	void ReplayRecoverGenerateDSCheckpoint(const struct FString& InReplayName);
	void PreInitGameState();
	void InitConsoleVar(const struct FString& Command);
	void GenReplayDone(const struct FString& ErrorMsg);
	void DSPlayerKickOut(uint64_t UID, const struct FName& PlayerType, const struct FString& ExitReason);
};


// Class MainCity.MainCityGameModeStateActive
// 0x0000 (0x0088 - 0x0088)
class UMainCityGameModeStateActive : public UGameModeStateActive
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCityGameModeStateActive");
		return pStaticClass;
	}

};


// Class MainCity.MainCityGameModeStateFighting
// 0x0000 (0x0090 - 0x0090)
class UMainCityGameModeStateFighting : public UGameModeStateFighting
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCityGameModeStateFighting");
		return pStaticClass;
	}

};


// Class MainCity.MainCityGameModeStateFinished
// 0x0000 (0x0088 - 0x0088)
class UMainCityGameModeStateFinished : public UGameModeStateFinished
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCityGameModeStateFinished");
		return pStaticClass;
	}

};


// Class MainCity.MainCityGameModeStateReady
// 0x0000 (0x00C8 - 0x00C8)
class UMainCityGameModeStateReady : public UGameModeStateReady
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCityGameModeStateReady");
		return pStaticClass;
	}

};


// Class MainCity.MainCityGameplayStatics
// 0x0000 (0x0020 - 0x0020)
class UMainCityGameplayStatics : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCityGameplayStatics");
		return pStaticClass;
	}


	struct FString GetProjectSavedDir();
};


// Class MainCity.MainCityGameState
// 0x0008 (0x1008 - 0x1000)
class AMainCityGameState : public ASTExtraGameStateBase
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x1000(0x0008) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCityGameState");
		return pStaticClass;
	}

};


// Class MainCity.MainCityHelper
// 0x0004 (0x0020 - 0x001C)
class UMainCityHelper : public UObject
{
public:
	unsigned char                                      UnknownData00[0x4];                                       // 0x001C(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCityHelper");
		return pStaticClass;
	}


	int SetSwapRolesForReplay(class AActor* InActor);
};


// Class MainCity.MainCityPlayerState
// 0x0000 (0x1678 - 0x1678)
class AMainCityPlayerState : public ASTExtraPlayerState
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCityPlayerState");
		return pStaticClass;
	}


	void RefreshAliasInfo(struct FGameModePlayerAliasInfo* PlayerAliasInfo);
};


// Class MainCity.MainCitySeesawAnimInstance
// 0x0030 (0x0330 - 0x0300)
class UMainCitySeesawAnimInstance : public UAnimInstance
{
public:
	unsigned char                                      UnknownData00[0x4];                                       // 0x0300(0x0004) MISSED OFFSET
	class UAssetPlayerSyncNode*                        AssetPlayerSyncNode;                                      // 0x0304(0x0004) (Edit, BlueprintVisible, BlueprintReadOnly, ZeroConstructor, DisableEditOnInstance, IsPlainOldData)
	bool                                               C_IsActivate;                                             // 0x0308(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_IsLooping;                                              // 0x0309(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x2];                                       // 0x030A(0x0002) MISSED OFFSET
	int                                                C_SeatAState;                                             // 0x030C(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                C_SeatBState;                                             // 0x0310(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                C_SeesawState;                                            // 0x0314(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_AKnockUp;                                               // 0x0318(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_BKnockUp;                                               // 0x0319(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_A_Idle;                                                 // 0x031A(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               C_A_Waiting;                                              // 0x031B(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               C_A_Entering;                                             // 0x031C(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               C_A_Entered;                                              // 0x031D(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               C_A_Exiting;                                              // 0x031E(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               C_B_Idle;                                                 // 0x031F(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_B_Waiting;                                              // 0x0320(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               C_B_Entering;                                             // 0x0321(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               C_B_Entered;                                              // 0x0322(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               C_B_Exiting;                                              // 0x0323(0x0001) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               C_IsEnterField;                                           // 0x0324(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_IsInGame;                                               // 0x0325(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               C_IsSpeedUp;                                              // 0x0326(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x9];                                       // 0x0327(0x0009) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCitySeesawAnimInstance");
		return pStaticClass;
	}


	void SyncAttachedActorAnimation();
};


// Class MainCity.MainCitySubsystem
// 0x0078 (0x0098 - 0x0020)
class UMainCitySubsystem : public UWorldSubsystem
{
public:
	unsigned char                                      UnknownData00[0x40];                                      // 0x0020(0x0040) MISSED OFFSET
	struct FName                                       FeatureDefaultPawnName;                                   // 0x0060(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FString                                     SkipLoadMapLevel;                                         // 0x0068(0x000C) (ZeroConstructor)
	bool                                               bShutdownUnrealNetwork;                                   // 0x0074(0x0001) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x1F];                                      // 0x0075(0x001F) MISSED OFFSET
	class ASTExtraBaseCharacter*                       InitialCharacter;                                         // 0x0094(0x0004) (ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MainCitySubsystem");
		return pStaticClass;
	}


	void SetHasInitLobbyAvatar(class ASTExtraPlayerController* InController, bool bInValue);
	void ResetMainCityGameState(class ASTExtraGameStateBase* InGameState);
	void PreShutdownUnrealNetwork();
	void PreEnterMainCityBattle();
	void PostShutdownUnrealNetwork();
	void PostPlayerActorChannelOpen();
	void PostInitialize();
	void PostEnterMainCityBattle();
	void PostDeinitialize();
	void PostClearActors();
	void KeepActor(class AActor* InActor);
	class ASTExtraBaseCharacter* InitStandalonePawn(class UClass* InClass, const struct FVector& InLocation, const struct FRotator& InRotation);
	void ClearActors();
};


// Class MainCity.MCAnimInstanceLocomotion
// 0x0010 (0x0A30 - 0x0A20)
class UMCAnimInstanceLocomotion : public UAnimInstanceLocomotion
{
public:
	bool                                               bUseCustomBS;                                             // 0x0A20(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0A21(0x0003) MISSED OFFSET
	class UBlendSpace*                                 BS_MovementStandCustom;                                   // 0x0A24(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBlendSpace*                                 BS_MovementCrouchCustom;                                  // 0x0A28(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UBlendSpace*                                 BS_MovementProneCustom;                                   // 0x0A2C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.MCAnimInstanceLocomotion");
		return pStaticClass;
	}

};


// Class MainCity.ReplayRecoverSubsystem
// 0x00F0 (0x0110 - 0x0020)
class UReplayRecoverSubsystem : public UGameInstanceSubsystem
{
public:
	unsigned char                                      UnknownData00[0x44];                                      // 0x0020(0x0044) MISSED OFFSET
	TArray<struct FString>                             IncludeWorldNames;                                        // 0x0064(0x000C) (ZeroConstructor, Config)
	TArray<unsigned char>                              LuaInfo;                                                  // 0x0070(0x000C) (ZeroConstructor)
	unsigned char                                      UnknownData01[0x4];                                       // 0x007C(0x0004) MISSED OFFSET
	int64_t                                            MaxTimeDelta;                                             // 0x0080(0x0008) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData02[0x88];                                      // 0x0088(0x0088) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class MainCity.ReplayRecoverSubsystem");
		return pStaticClass;
	}


	void WriteLuaInfo(TArray<unsigned char> InData);
	void SetReplayName(const struct FString& InReplayName);
	TArray<unsigned char> ReadLuaInfo();
	void PreInitializeWithParams(class UWorld* InWorld, class UNetDriver* InDriver);
	void PreInitializeForWorld(const struct FString& InURLStr, class UWorld* InWorld, class USTExtraGameInstance* InGameInstance);
	void PreInitializeForGameMode(const struct FString& InURLStr, class UWorld* InWorld, class AGameStateBase* InGameState);
	void PreDemoPlaybackEnded(class UWorld* InWorld);
	void PostInitializeWithParams(class UWorld* InWorld, class UNetDriver* InDriver);
	void PostInitializeForWorld(const struct FString& InURLStr, class UWorld* InWorld, class USTExtraGameInstance* InGameInstance);
	void PostInitializeForGameMode(const struct FString& InURLStr, class UWorld* InWorld, class AGameStateBase* InGameState);
	bool LuaSaveLuaInfo();
	void LoadReplayDone(const struct FString& ErrorMsg);
	bool IsVersionValid(const struct FString& RecordVersion, const struct FString& PlayerVersion);
	bool IsTimeValid(int64_t RecordTime, int64_t PlayTime);
	void GenReplayDone(const struct FString& ErrorMsg);
	void DeleteExpiredFiles(float MaxKeepHours);
	void ClearRecoverFile();
};


}

