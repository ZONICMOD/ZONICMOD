#pragma once

// PUBG MOBILE (3.9.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Mon Jul  7 13:18:10 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function HiggsBoson.BaziState.OnControllerReconnected
struct UBaziState_OnControllerReconnected_Params
{
};

// Function HiggsBoson.BaziState.AddChori
struct UBaziState_AddChori_Params
{
	struct FChori                                      Element;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function HiggsBoson.BaziState.AddBazi
struct UBaziState_AddBazi_Params
{
	struct FBazi                                       Element;                                                  // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function HiggsBoson.ClientGlueHiaSystem.Vulou
struct UClientGlueHiaSystem_Vulou_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc9
struct UClientGlueHiaSystem_LuaFunc9_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc8
struct UClientGlueHiaSystem_LuaFunc8_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc7
struct UClientGlueHiaSystem_LuaFunc7_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc6
struct UClientGlueHiaSystem_LuaFunc6_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc5
struct UClientGlueHiaSystem_LuaFunc5_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc4
struct UClientGlueHiaSystem_LuaFunc4_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc3
struct UClientGlueHiaSystem_LuaFunc3_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc2
struct UClientGlueHiaSystem_LuaFunc2_Params
{
};

// Function HiggsBoson.ClientGlueHiaSystem.LuaFunc1
struct UClientGlueHiaSystem_LuaFunc1_Params
{
	class AActor*                                      PtrActor;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func9
struct UClientGlueHiaSystem_Func9_Params
{
	class AActor*                                      PtrWeapon;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func8
struct UClientGlueHiaSystem_Func8_Params
{
	class AActor*                                      PtrWeapon;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	struct FBulletHitInfoUploadData                    UploadData;                                               // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FLocalShootHitData                          LocalHitData;                                             // (ConstParm, Parm, OutParm, ReferenceParm)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func7
struct UClientGlueHiaSystem_Func7_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func6
struct UClientGlueHiaSystem_Func6_Params
{
	class AActor*                                      Param1;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func3
struct UClientGlueHiaSystem_Func3_Params
{
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func27
struct UClientGlueHiaSystem_Func27_Params
{
	uint32_t                                           ShootID;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func26
struct UClientGlueHiaSystem_Func26_Params
{
	class AActor*                                      Param4;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Param5;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func25
struct UClientGlueHiaSystem_Func25_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Param2;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              param3;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Param4;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Param5;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func24
struct UClientGlueHiaSystem_Func24_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Param2;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              param3;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Param4;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Param5;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      Param6;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func23
struct UClientGlueHiaSystem_Func23_Params
{
	uint32_t                                           Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Param2;                                                   // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FHitResult                                  param3;                                                   // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func22
struct UClientGlueHiaSystem_Func22_Params
{
	uint32_t                                           Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Param2;                                                   // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FVector                                     param3;                                                   // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func21
struct UClientGlueHiaSystem_Func21_Params
{
	class AActor*                                      Param1;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func20
struct UClientGlueHiaSystem_Func20_Params
{
	class AActor*                                      Param1;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     Param2;                                                   // (Parm, OutParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func2
struct UClientGlueHiaSystem_Func2_Params
{
	class AActor*                                      CharacterPtr;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bParam1;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func19
struct UClientGlueHiaSystem_Func19_Params
{
	uint32_t                                           Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Param2;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              param3;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func18
struct UClientGlueHiaSystem_Func18_Params
{
	TArray<struct FBazi>                               Bazi;                                                     // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
	TArray<struct FChori>                              Chori;                                                    // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func17
struct UClientGlueHiaSystem_Func17_Params
{
	struct FFatalDamageParameter                       Param1;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func16
struct UClientGlueHiaSystem_Func16_Params
{
};

// Function HiggsBoson.ClientGlueHiaSystem.Func15
struct UClientGlueHiaSystem_Func15_Params
{
	class AActor*                                      Param1;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func14
struct UClientGlueHiaSystem_Func14_Params
{
	struct FShootTimeData                              InData;                                                   // (ConstParm, Parm, OutParm, ReferenceParm)
	class AActor*                                      PtrWeapon;                                                // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func11
struct UClientGlueHiaSystem_Func11_Params
{
	class AActor*                                      Param1;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func10
struct UClientGlueHiaSystem_Func10_Params
{
	class AActor*                                      Param1;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.ClientGlueHiaSystem.Func1
struct UClientGlueHiaSystem_Func1_Params
{
	class AActor*                                      CharacterPtr;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              TimeInSeconds;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              MarginInSeconds;                                          // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetUInt8ValueByName
struct UFuzzyObject_SetUInt8ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetUInt64ValueByName
struct UFuzzyObject_SetUInt64ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	uint64_t                                           Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetUInt32ValueByName
struct UFuzzyObject_SetUInt32ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetUInt16ValueByName
struct UFuzzyObject_SetUInt16ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	uint16_t                                           Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetInt8ValueByName
struct UFuzzyObject_SetInt8ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int8_t                                             Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetInt64ValueByName
struct UFuzzyObject_SetInt64ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetInt32ValueByName
struct UFuzzyObject_SetInt32ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetInt16ValueByName
struct UFuzzyObject_SetInt16ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int16_t                                            Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetFloatValueByName
struct UFuzzyObject_SetFloatValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.SetBoolValueByName
struct UFuzzyObject_SetBoolValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               Value;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetUInt8ValueByName
struct UFuzzyObject_GetUInt8ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetUInt64ValueByName
struct UFuzzyObject_GetUInt64ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	uint64_t                                           OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetUInt32ValueByName
struct UFuzzyObject_GetUInt32ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetUInt16ValueByName
struct UFuzzyObject_GetUInt16ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	uint16_t                                           OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetInt8ValueByName
struct UFuzzyObject_GetInt8ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int8_t                                             OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetInt64ValueByName
struct UFuzzyObject_GetInt64ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetInt32ValueByName
struct UFuzzyObject_GetInt32ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetInt16ValueByName
struct UFuzzyObject_GetInt16ValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int16_t                                            OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetFloatValueByName
struct UFuzzyObject_GetFloatValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.FuzzyObject.GetBoolValueByName
struct UFuzzyObject_GetBoolValueByName_Params
{
	int                                                Name;                                                     // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               OutValue;                                                 // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.ClientAmaUbaSubsystem.Func1
struct UClientAmaUbaSubsystem_Func1_Params
{
	int                                                IntType;                                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              InTimestamp;                                              // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                IncreaseCount;                                            // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bAlertUploadFrequency;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.CamoyoHelper.MakeRectTu
struct UCamoyoHelper_MakeRectTu_Params
{
	struct FScriptDelegate                             CamoyoRetDelegate;                                        // (Parm, ZeroConstructor)
	struct FString                                     Filename;                                                 // (Parm, ZeroConstructor)
	int                                                Quality;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bShowUI;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.CamoyoHelper.MakeMemPerform
struct UCamoyoHelper_MakeMemPerform_Params
{
	int                                                InbOpen;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.CamoyoHelper.MakeFitRectTu
struct UCamoyoHelper_MakeFitRectTu_Params
{
	struct FScriptDelegate                             CamoyoRetDelegate;                                        // (Parm, ZeroConstructor)
	struct FVector4                                    InCutParam;                                               // (Parm, IsPlainOldData)
	int                                                InTuType;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               isShowUI;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.Zanwu
struct UHiggsBosonComponent_Zanwu_Params
{
	struct FString                                     Param1;                                                   // (Parm, ZeroConstructor)
};

// Function HiggsBoson.HiggsBosonComponent.SyncServerParam
struct UHiggsBosonComponent_SyncServerParam_Params
{
	bool                                               Param1;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.SwiftHawk
struct UHiggsBosonComponent_SwiftHawk_Params
{
	TArray<unsigned char>                              Hawks;                                                    // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
	uint32_t                                           Magic;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.ShowABCD
struct UHiggsBosonComponent_ShowABCD_Params
{
	struct FString                                     Message;                                                  // (Parm, ZeroConstructor)
	bool                                               bIsClientShowWindow;                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.SetSchemeForInitialize
struct UHiggsBosonComponent_SetSchemeForInitialize_Params
{
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           VerifyLen;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              VerifyHashArray;                                          // (Parm, ZeroConstructor)
	TArray<struct FPatchPoint>                         PatchPointArray;                                          // (Parm, ZeroConstructor)
};

// Function HiggsBoson.HiggsBosonComponent.SetSchemeForGet
struct UHiggsBosonComponent_SetSchemeForGet_Params
{
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           VerifyLen;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              VerifyHashArray;                                          // (Parm, ZeroConstructor)
	TArray<struct FPatchPoint>                         PatchPointArray;                                          // (Parm, ZeroConstructor)
};

// Function HiggsBoson.HiggsBosonComponent.ServerPoPo
struct UHiggsBosonComponent_ServerPoPo_Params
{
	TArray<unsigned char>                              Array;                                                    // (Parm, OutParm, ZeroConstructor)
};

// Function HiggsBoson.HiggsBosonComponent.SendMoveStatusToServer
struct UHiggsBosonComponent_SendMoveStatusToServer_Params
{
	EPawnState                                         State;                                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.S2CNuoro
struct UHiggsBosonComponent_S2CNuoro_Params
{
	int                                                Lotion;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.RPC_ServerGlueHiaPark
struct UHiggsBosonComponent_RPC_ServerGlueHiaPark_Params
{
	int8_t                                             HiaType;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              GlueHiaParkArr;                                           // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
	uint32_t                                           HiaStatus;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              GlueArg;                                                  // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
	TArray<unsigned char>                              GlueHiaParkArr2;                                          // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
	uint32_t                                           HiaStatus2;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.RPC_ServerCapbo
struct UHiggsBosonComponent_RPC_ServerCapbo_Params
{
	int8_t                                             BoCapC;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int8_t                                             InBoType;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              BoDataArr;                                                // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
};

// Function HiggsBoson.HiggsBosonComponent.RPC_ServerAddInvalidFilesInPakLite
struct UHiggsBosonComponent_RPC_ServerAddInvalidFilesInPakLite_Params
{
	TArray<int>                                        InvalidIndexList;                                         // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
};

// Function HiggsBoson.HiggsBosonComponent.RPC_ClientCoronaLab
struct UHiggsBosonComponent_RPC_ClientCoronaLab_Params
{
	unsigned char                                      bAllSwitch;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              CoronaLab;                                                // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
	uint32_t                                           CoronaState;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnWeaponAimInput
struct UHiggsBosonComponent_OnWeaponAimInput_Params
{
	float                                              InDistToEnemy;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InYaw;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InPitch;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InRoll;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnTouchInput
struct UHiggsBosonComponent_OnTouchInput_Params
{
	float                                              InYaw;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InPitch;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InRoll;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnStopFireEvent
struct UHiggsBosonComponent_OnStopFireEvent_Params
{
};

// Function HiggsBoson.HiggsBosonComponent.OnStartFireEvent
struct UHiggsBosonComponent_OnStartFireEvent_Params
{
};

// Function HiggsBoson.HiggsBosonComponent.OnSkillInteruptVisual
struct UHiggsBosonComponent_OnSkillInteruptVisual_Params
{
	class AActor*                                      InTarget;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      InCauser;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnSkillEndVisual
struct UHiggsBosonComponent_OnSkillEndVisual_Params
{
	class AActor*                                      InTarget;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      InCauser;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnSkillEndTrans
struct UHiggsBosonComponent_OnSkillEndTrans_Params
{
	class AActor*                                      InTarget;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      InCauser;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnSkillBeginVisual
struct UHiggsBosonComponent_OnSkillBeginVisual_Params
{
	class AActor*                                      InTarget;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      InCauser;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnSkillBeginTrans
struct UHiggsBosonComponent_OnSkillBeginTrans_Params
{
	class AActor*                                      InTarget;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	class AActor*                                      InCauser;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnRecoilCurveCheckFailed
struct UHiggsBosonComponent_OnRecoilCurveCheckFailed_Params
{
	class AActor*                                      Weapon;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeOut
struct UHiggsBosonComponent_OnPlayerScopeOut_Params
{
	bool                                               bBegan;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnPlayerScopeIn
struct UHiggsBosonComponent_OnPlayerScopeIn_Params
{
	bool                                               bBegan;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnMyPawnRespawn
struct UHiggsBosonComponent_OnMyPawnRespawn_Params
{
	class AUAEPlayerController*                        InPlayerController;                                       // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnKillSomeOneEvent
struct UHiggsBosonComponent_OnKillSomeOneEvent_Params
{
	class AActor*                                      InSomeOne;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnGyroInput
struct UHiggsBosonComponent_OnGyroInput_Params
{
	float                                              InYaw;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InPitch;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              InRoll;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnClientAdjustPosition
struct UHiggsBosonComponent_OnClientAdjustPosition_Params
{
	struct FVector                                     NewLoc;                                                   // (Parm, IsPlainOldData)
	ECharacterMoveDragReason                           Reason;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.OnCapboReturn
struct UHiggsBosonComponent_OnCapboReturn_Params
{
	int                                                BoCapC;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                InBoType;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	TArray<unsigned char>                              RetData;                                                  // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function HiggsBoson.HiggsBosonComponent.OnBulletImpactEvent
struct UHiggsBosonComponent_OnBulletImpactEvent_Params
{
	class AActor*                                      InCauser;                                                 // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FHitResult                                  InImpactResult;                                           // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.IsCharacterOwnerWerewolf
struct UHiggsBosonComponent_IsCharacterOwnerWerewolf_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.IsCharacterOwnerButcher
struct UHiggsBosonComponent_IsCharacterOwnerButcher_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.HandleClientReconnect
struct UHiggsBosonComponent_HandleClientReconnect_Params
{
};

// Function HiggsBoson.HiggsBosonComponent.FlushGameEnd
struct UHiggsBosonComponent_FlushGameEnd_Params
{
};

// Function HiggsBoson.HiggsBosonComponent.Ezio
struct UHiggsBosonComponent_Ezio_Params
{
	int                                                Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                Param2;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                param3;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                Param4;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.EnableTickEncrypt
struct UHiggsBosonComponent_EnableTickEncrypt_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.EnablePeekShootVerify
struct UHiggsBosonComponent_EnablePeekShootVerify_Params
{
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.EnableEnhancedDynamicActors
struct UHiggsBosonComponent_EnableEnhancedDynamicActors_Params
{
	int                                                Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.EnableCheckFilesInPakLite
struct UHiggsBosonComponent_EnableCheckFilesInPakLite_Params
{
	TArray<struct FString>                             InFiles;                                                  // (ConstParm, Parm, ZeroConstructor)
	int                                                InVerifyCountSinglePass;                                  // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.DispatchIntegrityCheckItem
struct UHiggsBosonComponent_DispatchIntegrityCheckItem_Params
{
	uint32_t                                           PlatID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           AreaID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           GameBits;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           Index;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                Offset;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           Len;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           Type;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.DevPVSCheckClientLocationC2S
struct UHiggsBosonComponent_DevPVSCheckClientLocationC2S_Params
{
	class ASTExtraBaseCharacter*                       PtrOtherCharacter;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     D;                                                        // (ConstParm, Parm, ReferenceParm, IsPlainOldData)
	struct FVector                                     A;                                                        // (ConstParm, Parm, ReferenceParm, IsPlainOldData)
	struct FVector                                     V;                                                        // (ConstParm, Parm, ReferenceParm, IsPlainOldData)
	struct FVector                                     C;                                                        // (ConstParm, Parm, ReferenceParm, IsPlainOldData)
	bool                                               b1;                                                       // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.DevPVSCheckClientLocation
struct UHiggsBosonComponent_DevPVSCheckClientLocation_Params
{
	class AActor*                                      PtrSimulatedProxy;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     D;                                                        // (ConstParm, Parm, ReferenceParm, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.DevPrintMouke
struct UHiggsBosonComponent_DevPrintMouke_Params
{
	struct FString                                     Param0;                                                   // (Parm, ZeroConstructor)
	float                                              Param1;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     param3;                                                   // (Parm, ZeroConstructor)
};

// Function HiggsBoson.HiggsBosonComponent.ControlRoofTouch
struct UHiggsBosonComponent_ControlRoofTouch_Params
{
	int                                                Switch;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.ControlMoveInputRecord
struct UHiggsBosonComponent_ControlMoveInputRecord_Params
{
	int                                                Switch;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              RecordCooldown;                                           // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                BitmapSize;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	int                                                MinValidSampleCount;                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           InAngleSampleMaxCount;                                    // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	uint32_t                                           InAngleDistributionNum;                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.ControlMHActive
struct UHiggsBosonComponent_ControlMHActive_Params
{
	int                                                Switch;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.Cofew
struct UHiggsBosonComponent_Cofew_Params
{
	uint32_t                                           InIter;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawkWithParams
struct UHiggsBosonComponent_ClientSwiftHawkWithParams_Params
{
	TArray<unsigned char>                              Hawks;                                                    // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
};

// Function HiggsBoson.HiggsBosonComponent.ClientSwiftHawk
struct UHiggsBosonComponent_ClientSwiftHawk_Params
{
	unsigned char                                      Type;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SequenceID;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.ClientReceiveEx
struct UHiggsBosonComponent_ClientReceiveEx_Params
{
	TArray<unsigned char>                              RPCConstArray;                                            // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
};

// Function HiggsBoson.HiggsBosonComponent.ClientDoJT
struct UHiggsBosonComponent_ClientDoJT_Params
{
	bool                                               bDelayUntilShot;                                          // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.ClientCloseBaziUI
struct UHiggsBosonComponent_ClientCloseBaziUI_Params
{
	TArray<struct FBazi>                               Bazi;                                                     // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
	TArray<struct FChori>                              Chori;                                                    // (ConstParm, Parm, ZeroConstructor, ReferenceParm)
};

// Function HiggsBoson.HiggsBosonComponent.ClientAccom
struct UHiggsBosonComponent_ClientAccom_Params
{
	uint16_t                                           Owea;                                                     // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.HiggsBosonComponent.C2SSendAlert
struct UHiggsBosonComponent_C2SSendAlert_Params
{
	struct FString                                     Param1;                                                   // (Parm, ZeroConstructor)
};

// Function HiggsBoson.MarginIntervalCharacterTicker.Reset
struct UMarginIntervalCharacterTicker_Reset_Params
{
};

// Function HiggsBoson.SecurityAvatarSystem.OnAvatarRectifyDataChange
struct USecurityAvatarSystem_OnAvatarRectifyDataChange_Params
{
	class AUAECharacter*                               CharacterOwner;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ItemId;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.SecurityAvatarSystem.OnAvatarEquipped
struct USecurityAvatarSystem_OnAvatarEquipped_Params
{
	class AUAECharacter*                               CharacterOwner;                                           // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                SlotID;                                                   // (Parm, ZeroConstructor, IsPlainOldData)
	struct FItemDefineID                               NewItemID;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
	struct FItemDefineID                               OldItemID;                                                // (ConstParm, Parm, OutParm, ReferenceParm)
};

// Function HiggsBoson.SecurityImprisonComp.ReleaseTeammate
struct USecurityImprisonComp_ReleaseTeammate_Params
{
	uint64_t                                           PlayerUID;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.SecurityImprisonComp.ImprisonmentUIUpdate
struct USecurityImprisonComp_ImprisonmentUIUpdate_Params
{
	uint64_t                                           PlayerUID;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIsImprison;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.SecurityImprisonComp.ImprisonmentTeammate
struct USecurityImprisonComp_ImprisonmentTeammate_Params
{
	uint64_t                                           PlayerUID;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bIscomplaint;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.SecurityImprisonComp.ImprisonmentReport
struct USecurityImprisonComp_ImprisonmentReport_Params
{
	uint64_t                                           PlayerUID;                                                // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function HiggsBoson.TimeIntervalPawnStateHistorySystem.UpdateParams
struct UTimeIntervalPawnStateHistorySystem_UpdateParams_Params
{
};

// Function HiggsBoson.TimeIntervalPawnStateHistorySystem.QueryHistoryMaxVelocity
struct UTimeIntervalPawnStateHistorySystem_QueryHistoryMaxVelocity_Params
{
	uint64_t                                           UID;                                                      // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              CenterTime;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              MarginTime;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              OutMaxZVelocity;                                          // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	float                                              OutMaxXYVelocity;                                         // (Parm, OutParm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

}

