#pragma once

// PUBG MOBILE (3.9.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Mon Jul  7 13:18:13 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ClusterReplication.ClusterReplicationSubsystem.SetAutoClearCache
struct UClusterReplicationSubsystem_SetAutoClearCache_Params
{
	bool                                               Val;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClusterReplication.ClusterReplicationSubsystem.SetAutoCache
struct UClusterReplicationSubsystem_SetAutoCache_Params
{
	bool                                               Val;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function ClusterReplication.ClusterReplicationSubsystem.RemoveAllCachedObjectData
struct UClusterReplicationSubsystem_RemoveAllCachedObjectData_Params
{
};

}

