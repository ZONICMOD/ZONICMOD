#pragma once

// PUBG MOBILE (3.9.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Mon Jul  7 13:18:14 2025
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function MainCity.CarryBackMCAnimInstance.HandlePlayerPoseChange
struct UCarryBackMCAnimInstance_HandlePlayerPoseChange_Params
{
	TEnumAsByte<ESTEPoseState>                         LastPose;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ESTEPoseState>                         NewPose;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.CharLocomotionMCAnimInstance.SwitchingPoseFinishCallback
struct UCharLocomotionMCAnimInstance_SwitchingPoseFinishCallback_Params
{
};

// Function MainCity.CharLocomotionMCAnimInstance.SetViewPointLimitByPoseStatus
struct UCharLocomotionMCAnimInstance_SetViewPointLimitByPoseStatus_Params
{
	ECharacterAnimBlendPoseType                        InPoseType;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bEnter;                                                   // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.CharLocomotionMCAnimInstance.SetInterruptPose
struct UCharLocomotionMCAnimInstance_SetInterruptPose_Params
{
	bool                                               bUseInterruptPose;                                        // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ECharacterPoseType>                    InterruptPose;                                            // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.CharLocomotionMCAnimInstance.LeaveStateCallback
struct UCharLocomotionMCAnimInstance_LeaveStateCallback_Params
{
};

// Function MainCity.CharLocomotionMCAnimInstance.HandleStateLeave
struct UCharLocomotionMCAnimInstance_HandleStateLeave_Params
{
	EPawnState                                         LeaveState;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.CharLocomotionMCAnimInstance.HandlePlayerPoseChange
struct UCharLocomotionMCAnimInstance_HandlePlayerPoseChange_Params
{
	TEnumAsByte<ESTEPoseState>                         LastPose;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<ESTEPoseState>                         NewPose;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.CharMainMCAnimInstance.SetClimbAnimation
struct UCharMainMCAnimInstance_SetClimbAnimation_Params
{
	class UAnimSequence*                               AnimSequence;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bFlag;                                                    // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.CharMainMCAnimInstance.HandlePlayerAnimMontagePlayExtraDelegate
struct UCharMainMCAnimInstance_HandlePlayerAnimMontagePlayExtraDelegate_Params
{
	class UAnimMontage*                                MontageToPlay;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bWantsPlay;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              PlayRate;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       StartSection;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              StartPos;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bOnlyJumpToSectionWhilePlaying;                           // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       IgnoreStopSection;                                        // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.CharMainMCAnimInstance.HandlePlayerAnimMontagePlayDelegate
struct UCharMainMCAnimInstance_HandlePlayerAnimMontagePlayDelegate_Params
{
	class UAnimMontage*                                MontageToPlay;                                            // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bWantsPlay;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              PlayRate;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       StartSection;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              StartPos;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.CharMainMCAnimInstance.HandleAnimPlaySlotAnimDelegate
struct UCharMainMCAnimInstance_HandleAnimPlaySlotAnimDelegate_Params
{
	class UAnimSequenceBase*                           AnimSequence;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bWantsPlay;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       SlotName;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              PlayRate;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	float                                              BlendTime;                                                // (Parm, ZeroConstructor, IsPlainOldData)
	unsigned char                                      InLoopCount;                                              // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              InStartPos;                                               // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
	float                                              LoopStartPos;                                             // (ConstParm, Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.MainCityGameMode.ReplayRecoverGenerateDSCheckpoint
struct AMainCityGameMode_ReplayRecoverGenerateDSCheckpoint_Params
{
	struct FString                                     InReplayName;                                             // (Parm, ZeroConstructor)
};

// Function MainCity.MainCityGameMode.PreInitGameState
struct AMainCityGameMode_PreInitGameState_Params
{
};

// Function MainCity.MainCityGameMode.InitConsoleVar
struct AMainCityGameMode_InitConsoleVar_Params
{
	struct FString                                     Command;                                                  // (Parm, ZeroConstructor)
};

// Function MainCity.MainCityGameMode.GenReplayDone
struct AMainCityGameMode_GenReplayDone_Params
{
	struct FString                                     ErrorMsg;                                                 // (Parm, ZeroConstructor)
};

// Function MainCity.MainCityGameMode.DSPlayerKickOut
struct AMainCityGameMode_DSPlayerKickOut_Params
{
	uint64_t                                           UID;                                                      // (Parm, ZeroConstructor, IsPlainOldData)
	struct FName                                       PlayerType;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	struct FString                                     ExitReason;                                               // (Parm, ZeroConstructor)
};

// Function MainCity.MainCityGameplayStatics.GetProjectSavedDir
struct UMainCityGameplayStatics_GetProjectSavedDir_Params
{
	struct FString                                     ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function MainCity.MainCityHelper.SetSwapRolesForReplay
struct UMainCityHelper_SetSwapRolesForReplay_Params
{
	class AActor*                                      InActor;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	int                                                ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function MainCity.MainCityPlayerState.RefreshAliasInfo
struct AMainCityPlayerState_RefreshAliasInfo_Params
{
	struct FGameModePlayerAliasInfo                    PlayerAliasInfo;                                          // (Parm, OutParm)
};

// Function MainCity.MainCitySeesawAnimInstance.SyncAttachedActorAnimation
struct UMainCitySeesawAnimInstance_SyncAttachedActorAnimation_Params
{
};

// Function MainCity.MainCitySubsystem.SetHasInitLobbyAvatar
struct UMainCitySubsystem_SetHasInitLobbyAvatar_Params
{
	class ASTExtraPlayerController*                    InController;                                             // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               bInValue;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.MainCitySubsystem.ResetMainCityGameState
struct UMainCitySubsystem_ResetMainCityGameState_Params
{
	class ASTExtraGameStateBase*                       InGameState;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.MainCitySubsystem.PreShutdownUnrealNetwork
struct UMainCitySubsystem_PreShutdownUnrealNetwork_Params
{
};

// Function MainCity.MainCitySubsystem.PreEnterMainCityBattle
struct UMainCitySubsystem_PreEnterMainCityBattle_Params
{
};

// Function MainCity.MainCitySubsystem.PostShutdownUnrealNetwork
struct UMainCitySubsystem_PostShutdownUnrealNetwork_Params
{
};

// Function MainCity.MainCitySubsystem.PostPlayerActorChannelOpen
struct UMainCitySubsystem_PostPlayerActorChannelOpen_Params
{
};

// Function MainCity.MainCitySubsystem.PostInitialize
struct UMainCitySubsystem_PostInitialize_Params
{
};

// Function MainCity.MainCitySubsystem.PostEnterMainCityBattle
struct UMainCitySubsystem_PostEnterMainCityBattle_Params
{
};

// Function MainCity.MainCitySubsystem.PostDeinitialize
struct UMainCitySubsystem_PostDeinitialize_Params
{
};

// Function MainCity.MainCitySubsystem.PostClearActors
struct UMainCitySubsystem_PostClearActors_Params
{
};

// Function MainCity.MainCitySubsystem.KeepActor
struct UMainCitySubsystem_KeepActor_Params
{
	class AActor*                                      InActor;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.MainCitySubsystem.InitStandalonePawn
struct UMainCitySubsystem_InitStandalonePawn_Params
{
	class UClass*                                      InClass;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	struct FVector                                     InLocation;                                               // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	struct FRotator                                    InRotation;                                               // (ConstParm, Parm, OutParm, ReferenceParm, IsPlainOldData)
	class ASTExtraBaseCharacter*                       ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function MainCity.MainCitySubsystem.ClearActors
struct UMainCitySubsystem_ClearActors_Params
{
};

// Function MainCity.ReplayRecoverSubsystem.WriteLuaInfo
struct UReplayRecoverSubsystem_WriteLuaInfo_Params
{
	TArray<unsigned char>                              InData;                                                   // (ConstParm, Parm, OutParm, ZeroConstructor, ReferenceParm)
};

// Function MainCity.ReplayRecoverSubsystem.SetReplayName
struct UReplayRecoverSubsystem_SetReplayName_Params
{
	struct FString                                     InReplayName;                                             // (Parm, ZeroConstructor)
};

// Function MainCity.ReplayRecoverSubsystem.ReadLuaInfo
struct UReplayRecoverSubsystem_ReadLuaInfo_Params
{
	TArray<unsigned char>                              ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm)
};

// Function MainCity.ReplayRecoverSubsystem.PreInitializeWithParams
struct UReplayRecoverSubsystem_PreInitializeWithParams_Params
{
	class UWorld*                                      InWorld;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class UNetDriver*                                  InDriver;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.PreInitializeForWorld
struct UReplayRecoverSubsystem_PreInitializeForWorld_Params
{
	struct FString                                     InURLStr;                                                 // (Parm, ZeroConstructor)
	class UWorld*                                      InWorld;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class USTExtraGameInstance*                        InGameInstance;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.PreInitializeForGameMode
struct UReplayRecoverSubsystem_PreInitializeForGameMode_Params
{
	struct FString                                     InURLStr;                                                 // (Parm, ZeroConstructor)
	class UWorld*                                      InWorld;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class AGameStateBase*                              InGameState;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.PreDemoPlaybackEnded
struct UReplayRecoverSubsystem_PreDemoPlaybackEnded_Params
{
	class UWorld*                                      InWorld;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.PostInitializeWithParams
struct UReplayRecoverSubsystem_PostInitializeWithParams_Params
{
	class UWorld*                                      InWorld;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class UNetDriver*                                  InDriver;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.PostInitializeForWorld
struct UReplayRecoverSubsystem_PostInitializeForWorld_Params
{
	struct FString                                     InURLStr;                                                 // (Parm, ZeroConstructor)
	class UWorld*                                      InWorld;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class USTExtraGameInstance*                        InGameInstance;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.PostInitializeForGameMode
struct UReplayRecoverSubsystem_PostInitializeForGameMode_Params
{
	struct FString                                     InURLStr;                                                 // (Parm, ZeroConstructor)
	class UWorld*                                      InWorld;                                                  // (Parm, ZeroConstructor, IsPlainOldData)
	class AGameStateBase*                              InGameState;                                              // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.LuaSaveLuaInfo
struct UReplayRecoverSubsystem_LuaSaveLuaInfo_Params
{
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.LoadReplayDone
struct UReplayRecoverSubsystem_LoadReplayDone_Params
{
	struct FString                                     ErrorMsg;                                                 // (Parm, ZeroConstructor)
};

// Function MainCity.ReplayRecoverSubsystem.IsVersionValid
struct UReplayRecoverSubsystem_IsVersionValid_Params
{
	struct FString                                     RecordVersion;                                            // (Parm, ZeroConstructor)
	struct FString                                     PlayerVersion;                                            // (Parm, ZeroConstructor)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.IsTimeValid
struct UReplayRecoverSubsystem_IsTimeValid_Params
{
	int64_t                                            RecordTime;                                               // (Parm, ZeroConstructor, IsPlainOldData)
	int64_t                                            PlayTime;                                                 // (Parm, ZeroConstructor, IsPlainOldData)
	bool                                               ReturnValue;                                              // (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.GenReplayDone
struct UReplayRecoverSubsystem_GenReplayDone_Params
{
	struct FString                                     ErrorMsg;                                                 // (Parm, ZeroConstructor)
};

// Function MainCity.ReplayRecoverSubsystem.DeleteExpiredFiles
struct UReplayRecoverSubsystem_DeleteExpiredFiles_Params
{
	float                                              MaxKeepHours;                                             // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function MainCity.ReplayRecoverSubsystem.ClearRecoverFile
struct UReplayRecoverSubsystem_ClearRecoverFile_Params
{
};

}

