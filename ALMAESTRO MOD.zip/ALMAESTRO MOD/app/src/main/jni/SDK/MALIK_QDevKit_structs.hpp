#pragma once

// PUBG MOBILE (3.9.0) TELEGRAM MALIK:-@K_Y_2  
// GENERATE ON Mon Jul  7 13:18:15 2025
 
namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum QDevKit.EQFirebaseRemoteConfigStatus
enum class EQFirebaseRemoteConfigStatus : uint8_t
{
	EQFirebaseRemoteConfigStatus__kUnfetched = 0,
	EQFirebaseRemoteConfigStatus__kFetchedSuccessfully = 1,
	EQFirebaseRemoteConfigStatus__kFetchedFailed = 2,
	EQFirebaseRemoteConfigStatus__EQFirebaseRemoteConfigStatus_MAX = 3
};



}

